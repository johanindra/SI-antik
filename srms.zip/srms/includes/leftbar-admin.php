<div class="left-sidebar bg-black-300 box-shadow">
  <div class="sidebar-content">
    <div class="user-info closed">
      <img src="https://via.placeholder.com/90/c2c2c2?text=Admin" alt="John Doe" class="img-circle profile-img" />
      <h6 class="title">Admin Desa</h6>
      <small class="info">Admin Desa Bulusari</small>
    </div>
    <!-- /.user-info -->

    <div class="sidebar-nav">
      <ul class="side-nav color-gray">
        <li>
          <a href="dashboard-admin.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>

        <li>
          <a href="data-admin.php"><i class="fa fa-user"></i> <span>Data Admin Kader</span>
          </a>
        </li>
        <li>
          <a href="data-user.php"><i class="fa fa-users"></i> <span>Data User Mobile</span>
          </a>
        </li>
      </ul>
    </div>
    <!-- /.sidebar-nav -->
  </div>
  <!-- /.sidebar-content -->
</div>